import java.io.*;
import javax.servlet.*;
import java.sql.*;


public class procedure extends GenericServlet {
	Connection con;
	public void init()throws ServletException
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");  
		 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance","root","@shwini25");	
		}catch(Exception e)
		{
			System.out.print(e);
		}	
	}
	public void service(ServletRequest request,
			ServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");  
		PrintWriter pw = response.getWriter();  
		
		
		try{
			CallableStatement st=con.prepareCall("{call shortage()} ");
		 // st.setString(1,br);
			ResultSet rs=st.executeQuery();
			pw.println("<b><u>attendence shortage list</u></b>");
		     while(rs.next())  
			{
			String u=rs.getString("STUDENT_ID");	
			String ln=rs.getString("STUDENT_NAME");
			String a=rs.getString("ATTENDANCE_STATUS");
			
			pw.print("<table>");
			pw.println("<tr><th>STUDENT_ID:</th><td>"+u+"</td></tr>");
			pw.println("<tr><th>STUDENT_NAME:</th><td>"+ln+"</td></tr>");
			pw.println("<tr><th>ATTENDANCE_STATUS</th><td>"+a+"</td></tr></br></br>");
		//	pw.println("<tr><th>Address</th><td>"+ad+"</td></tr></br></br>");  	
			  
			}
		     
	
			
		}catch(Exception e)
		{
			
			pw.println(
					e);
		}
		
		
		
		


		pw.close();
	}

}

