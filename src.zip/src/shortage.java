import java.io.*; 
import java.sql.*;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;  
import javax.servlet.http.*;  

import javax.servlet.http.HttpServlet;


public class shortage extends HttpServlet {
	public void doPost(HttpServletRequest request, HttpServletResponse response)  
    throws ServletException, IOException {  

response.setContentType("text/html");  
PrintWriter pw = response.getWriter();  
String u=request.getParameter("STUDENT_ID");
try{
	Class.forName("com.mysql.jdbc.Driver");  
	Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/attendance","root","@shwini25"); 
	PreparedStatement st=con.prepareStatement("select s.STUDENT_ID,s.STUDENT_NAME,s.SEM,s.SEC,s.AGE,s.BRANCH,s.EMAIL,su.SUBJECT_CODE,su.SUBJECT_NAME,FACULTY_NAME,CLASS_TAKEN, CLASS_ATTENDED,ATTENDENCE_STATUS,MESSAGE from inform1 i,student1 s,subject1 su,faculty1 f,attendence1 a where s.STUDENT_ID=a.STUDENT_ID and su.SUBJECT_CODE=a.SUBJECT_CODE and f.FACULTY_ID=su.FACULTY_ID and s.STUDENT_ID=i.STUDENT_ID and s.STUDENT_ID=?");
	
  st.setString(1,u);
	ResultSet rs=st.executeQuery();
     while(rs.next())  
	{ String us=rs.getString("s.STUDENT_ID");
    	   String fn1=rs.getString("s.STUDENT_NAME");
		    String sem1=rs.getString("s.SEM");
		    String sec=rs.getString("s.SEC");
		    String age=rs.getString("s.AGE");
		    String branch=rs.getString("s.BRANCH");
		    String email=rs.getString("EMAIL");
		    String sname1=rs.getString("SUBJECT_CODE");
		    String ct2=rs.getString("CLASS_TAKEN");
			String cat1=rs.getString("CLASS_ATTENDED");
			String a1=rs.getString("ATTENDENCE_STATUS");
			String m=rs.getString("MESSAGE");
			pw.println("<table>");
			pw.println("<tr><th>usn</th><td>"+us+"</td></tr>");
			pw.println("<tr><th>first_name</th><td>"+fn1+"</td></tr>");
			pw.println( "<tr><th>sem</th><td>"+sem1+"</td></tr>");
			pw.println("<tr><th>sec</th><td>"+sec+"</td></tr>");
			pw.println("<th>age</th><td>"+age+"</td></tr>");
			pw.println( "<tr><th>branch</th><td>"+branch+"</td></tr>");
			pw.println( "<tr><th>email</th><td>"+email+"</td></tr>");
			pw.println("<tr><th>sname</th><td>"+sname1+"</td></tr>");
			pw.println( "<tr><th>class_taken</th><td>"+ct2+"</td></tr>");
			pw.println("<tr><th>class_attended</th><td>"+cat1+"</td></tr>");
			pw.println("<tr><th>attendence_status</th><td>"+a1+"</td></tr>");
			pw.println("<tr><th>attendence shortage or not</th><td>"+m+"</td></tr><br/><br/>");
			}
	
}catch(Exception e)
{
	
	pw.println(e);
}

pw.close();  
}  	

}
