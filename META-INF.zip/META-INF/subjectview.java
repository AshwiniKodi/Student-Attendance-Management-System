
import java.io.*;
import javax.servlet.*;
import java.sql.*;


public class subjectveiw extends GenericServlet {
	Connection con;
	public void init()throws ServletException
	{
		try{
			Class.forName("com.mysql.jdbc.Driver");  
		 con=DriverManager.getConnection("jdbc:mysql://localhost:3306/project1","root","root");	
		}catch(Exception e)
		{
			System.out.print(e);
		}	
	}
	public void service(ServletRequest request,
			ServletResponse response) throws ServletException, IOException
	{
		response.setContentType("text/html");  
		PrintWriter pw = response.getWriter();  
		//String fid=request.getParameter("faculty_id");
		//String fname=request.getParameter("faculty_name");
		//String age=request.getParameter("age");
		//int x=Integer.parseInt(age);
		//String ph=request.getParameter("phone_no");
		//String ad=request.getParameter("address");

		
	
		try{
			PreparedStatement st=con.prepareStatement("SELECT * FROM subject");
		  // st.setString(1,br);
			ResultSet rs=st.executeQuery();
			pw.println("<b><u>Subject Details</b></u>");
		     while(rs.next())  
			{
			String s=rs.getString("scode");	
			String sn=rs.getString("sname");
			String sem=rs.getString("sem");
			int x=Integer.parseInt(sem);
			String h=rs.getString("hours");
			int y=Integer.parseInt(h);
			String fid=rs.getString("faculty_id");	
			
			pw.print("<table>");
			pw.println("<tr><th>subject code</th><td>"+s+"</td></tr>");
			pw.print("<tr><th>subject name</th><td>"+sn+"</td></tr>");
			//pw.print("<tr><th>last_Name</th><td>"+ln+"</td></tr>");
			pw.print("<tr><th>sem</th><td>"+x+"</td></tr>");
			pw.print("<tr><th>hours</th><td>"+y+"</td></tr>");
			pw.print("<tr><th>faculty ID</th><td>"+fid+"</td></tr>");
			//pw.println("<tr><th>phone number</th><td>"+ph+"</td></tr>");
			//pw.println("<tr><th>Address</th><td>"+ad+"</td></tr>");
			//pw.println("<tr><th>Parent name</th><td>"+pn+"</td></tr></br></br>");  	
			  
			}
			
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		
		pw.close();
	}

}
